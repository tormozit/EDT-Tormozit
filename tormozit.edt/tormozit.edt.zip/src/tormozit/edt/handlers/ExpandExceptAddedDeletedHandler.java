package tormozit.edt.handlers;

import java.lang.reflect.Field;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.viewers.AbstractTreeViewer;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.ui.IEditorPart;

import com._1c.g5.v8.dt.compare.core.IComparisonSession;
import com._1c.g5.v8.dt.compare.model.MatchedObjectsComparisonNode;
import com._1c.g5.v8.dt.compare.ui.editor.DtComparisonView;

import tormozit.edt.selection.CompareEditorSelectionProvider;

/**
 * Разворачивает дерево сравнения EDT, пропуская добавленные/удалённые объекты.
 *
 * Логика:
 *   - MatchedObjectsComparisonNode с обеими сторонами (mainObjectId и otherObjectId)
 *     → объект изменён → раскрываем, рекурсивно обходим детей
 *   - MatchedObjectsComparisonNode только с одной стороной
 *     → объект добавлен или удалён → не раскрываем (и детей не смотрим)
 *   - Узлы других типов (группы, свойства) → раскрываем, обходим рекурсивно
 */
public class ExpandExceptAddedDeletedHandler
    extends AbstractHandler
{

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException
    {
//        IEditorPart editor = HandlerUtil.getActiveEditor(event);
//        if (editor == null)
//            return null;
//
//        return expand(editor);
        return null;
    }

    public static Object expand(IEditorPart editor, ExpandMode mode)
    {
        AbstractTreeViewer viewer = getTreeViewer(editor);
        if (viewer == null)
            return null;

        ITreeContentProvider cp = (ITreeContentProvider)viewer.getContentProvider();
        if (cp == null)
            return null;

        // Запоминаем текущую строку до сворачивания
        ISelection selection = viewer.getSelection();

        // Сворачиваем всё, затем раскрываем избирательно
        viewer.collapseAll();

        for (Object root : cp.getElements(viewer.getInput()))
        {
            expandSelectively(viewer, cp, root, mode, CompareEditorSelectionProvider.getSession(editor));
        }

        // Восстанавливаем выделение и прокручиваем к нему
        if (selection != null && !selection.isEmpty())
            viewer.setSelection(selection, true);

        return null;
    }

    /**
     * Рекурсивно раскрывает узел, если он не является добавленным/удалённым.
     */
    private static void expandSelectively(AbstractTreeViewer viewer, ITreeContentProvider cp, Object element,
        ExpandMode mode, IComparisonSession session)
    {
        if (!cp.hasChildren(element))
            return;
        if (mode == ExpandMode.toBothElement && isAddedOrDeleted(element))
            return;
        if (mode == ExpandMode.toObject && isObject(session, element))
            return;
        // Раскрываем на один уровень — это загружает дочерние элементы в вьюер
        viewer.expandToLevel(element, 1);

        for (Object child : cp.getChildren(element))
        {
            expandSelectively(viewer, cp, child, mode, session);
        }
    }

    private static boolean isObject(IComparisonSession session, Object element)
    {
        Object raw = invokeNoArg(element, "retrieveComparisonNode");
        if (!(raw instanceof MatchedObjectsComparisonNode))
            return false;
        MatchedObjectsComparisonNode node = (MatchedObjectsComparisonNode)raw;
        Long mainId = node.getMainObjectId();
        Long otherId = node.getOtherObjectId();
        return false
            || mainId != null && OpenObjectHandler.getEObject(session, mainId, node) != null
            || otherId != null && OpenObjectHandler.getEObject(session, otherId, node) != null;
    }

    /**
     * Возвращает true, если элемент является объектом, присутствующим
     * только в одной стороне сравнения (добавлен или удалён).
     */
    private static boolean isAddedOrDeleted(Object element)
    {
        Object raw = invokeNoArg(element, "retrieveComparisonNode");
        if (!(raw instanceof MatchedObjectsComparisonNode))
            return false;

        MatchedObjectsComparisonNode node = (MatchedObjectsComparisonNode)raw;
        Long mainId = node.getMainObjectId();
        Long otherId = node.getOtherObjectId();
        boolean hasMain = mainId != null && mainId != -1L;
        boolean hasOther = otherId != null && otherId != -1L;

        // Добавлен = нет главной стороны; удалён = нет другой стороны
        return false
            || !hasMain && hasOther
            || hasMain && !hasOther;
    }

    // ---- Получение TreeViewer из редактора ----

    private static AbstractTreeViewer getTreeViewer(IEditorPart editor)
    {
        Object view = getField(editor, "comparisonView");
        if (!(view instanceof DtComparisonView))
            return null;

        Object treeControl = ((DtComparisonView)view).getTreeControl();
        if (treeControl == null)
            return null;

        Object viewer = invokeNoArg(treeControl, "getTreeViewer");
        return (viewer instanceof AbstractTreeViewer) ? (AbstractTreeViewer)viewer : null;
    }

    // ---- Утилиты рефлексии ----

    private static Object getField(Object obj, String name)
    {
        Class<?> cls = obj.getClass();
        while (cls != null)
        {
            try
            {
                Field f = cls.getDeclaredField(name);
                f.setAccessible(true);
                return f.get(obj);
            }
            catch (NoSuchFieldException ignored)
            {
                cls = cls.getSuperclass();
            }
            catch (Exception ignored)
            {
                return null;
            }
        }
        return null;
    }

    private static Object invokeNoArg(Object o, String name)
    {
        if (o == null)
            return null;
        try
        {
            return o.getClass().getMethod(name).invoke(o);
        }
        catch (Exception ignored)
        {
            return null;
        }
    }
}
