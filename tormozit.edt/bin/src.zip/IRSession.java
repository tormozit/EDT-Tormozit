import java.time.LocalDateTime;
import java.util.concurrent.ExecutorService;

import org.eclipse.core.resources.IProject;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.TextSelection;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.xtext.ui.editor.model.IXtextDocument;

import com._1c.g5.v8.dt.bsl.ui.editor.BslXtextEditor;
import com._1c.g5.v8.dt.platform.services.model.InfobaseReference;

public final class IRSession
    {
        public final IRApplication.State state;
        public final LocalDateTime startTime;
        public final long pid;
        public final String platformVersion;
        final Object root;
        final Object processObj;
        public String appTitle;
        public IProject project;
        public final ExecutorService executor; // Выделенный поток для всех операций с этой COM-сессией
        /** Не null, если ИР подключён портативно (ирПортативный.epf), а не через расширение.
         *  В этом случае getModule() использует эту форму вместо root (COM-приложения). */
        public Object moduleRoot = null;
        public InfobaseReference infobase;
        public IRCodeEditor codeEditor = null;

        IRSession(IRApplication.State state, LocalDateTime startTime, long pid, String platformVersion,
                  Object root, Object processObj, String appTitle, IProject project, ExecutorService executor, InfobaseReference infobase)
        {
            this.state = state;
            this.startTime = startTime;
            this.pid = pid;
            this.platformVersion = platformVersion;
            this.root = root;
            this.processObj = processObj;
            this.appTitle = appTitle;
            this.project = project;
            this.executor = executor;
            this.infobase = infobase;
        }

        public Object getModule(String name)
        {
            return ComBridge.getProperty(moduleRoot != null ? moduleRoot : root, name);
        }
        public IRCodeEditor getCodeEditor(BslXtextEditor editor)
        {
            ISourceViewer viewer = editor.getInternalSourceViewer();
            Object sel = viewer.getSelectionProvider().getSelection();
//            if (!(sel instanceof ITextSelection)) 
//                return;
            ITextSelection textSelection = (ITextSelection) sel;
            IXtextDocument doc = (IXtextDocument)viewer.getDocument();
            String moduleName = ""; // TODO
            executor.submit(() ->
            {
                    if (codeEditor == null)
                    {
                        Object irCache = getModule("ирКэш");
                        codeEditor = new IRCodeEditor(ComBridge.invoke(irCache, "ПолеТекстаПрограммы", 0));
                    }
                    int offset = textSelection.getOffset();
                    codeEditor.setText(doc.get(), moduleName, offset, offset + textSelection.getLength());
            });
            return codeEditor;
        }

        /**
         * 
         */
        public void openTextEditor(String text, String sourceRef)
        {
            Object irClient = getModule("ирКлиент"); //$NON-NLS-1$
            // (Текст, Знач Заголовок = "", ВариантПросмотра = "Компактный", ТолькоПросмотр = Ложь, Знач КлючУникальности = Неопределено, ВладелецФормы = Неопределено, ВыделитьВсе = Ложь,
            // Знач Модально = Ложь, ВыделениеДвумерное = Неопределено, Знач ИскомаяСтрока = "", Знач КлючИсточника = "")
            ComBridge.invoke(irClient, "ОткрытьТекстЛкс", text, sourceRef, null, false, sourceRef, null, false, false, null, "", sourceRef); //$NON-NLS-1$                
        }
    }
